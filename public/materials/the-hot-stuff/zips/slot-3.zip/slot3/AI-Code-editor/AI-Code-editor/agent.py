"""
Minimal Claude-Code-style coding agent built by hand with LangGraph.

Uses a manual StateGraph (model -> tools -> model ... -> END) instead of
create_react_agent, so the control flow is visible and easy to modify.
"""

import os
import json
from pathlib import Path
from typing import Annotated, Sequence, TypedDict

from langchain_core.messages import BaseMessage, SystemMessage, HumanMessage, AIMessage, ToolMessage
from langchain_core.tools import tool
from langchain_ollama import ChatOllama
from langgraph.prebuilt import ToolNode
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langgraph.checkpoint.memory import MemorySaver
from dotenv import load_dotenv

load_dotenv()

import subprocess

# ---------- Safety: confine all file/terminal ops to one root ----------

PROJECT_ROOT = Path.cwd().resolve()

OLLAMA_MODEL = os.getenv("OLLAMA_MODEL")
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL")
OLLAMA_API_KEY = os.getenv("OLLAMA_API_KEY")


def resolve_abs_path(path_str: str) -> Path:
    """Resolve a path and make sure it stays inside PROJECT_ROOT."""
    p = Path(path_str).expanduser()
    full = p if p.is_absolute() else (PROJECT_ROOT / p)
    full = full.resolve()
    if not (full == PROJECT_ROOT or PROJECT_ROOT in full.parents):
        raise ValueError(f"Path '{path_str}' resolves outside the project root ({PROJECT_ROOT})")
    return full


# ---------- Tools ----------

@tool
def read_file(filename: str) -> dict:
    """Read the full content of a file."""
    full = resolve_abs_path(filename)
    if not full.is_file():
        return {"file_path": str(full), "error": "not found"}
    return {"file_path": str(full), "content": full.read_text(encoding="utf-8")}


@tool
def list_files(path: str = ".") -> dict:
    """List files and directories inside a directory."""
    full = resolve_abs_path(path)
    if not full.is_dir():
        return {"path": str(full), "error": "not a directory"}
    entries = [
        {"name": i.name, "type": "file" if i.is_file() else "dir"}
        for i in sorted(full.iterdir())
    ]
    return {"path": str(full), "entries": entries}


@tool
def edit_file(path: str, old_str: str, new_str: str) -> dict:
    """Edit a file. If old_str is empty, create/overwrite the file with new_str.
    Otherwise replace the first occurrence of old_str with new_str."""
    full = resolve_abs_path(path)
    existed = full.is_file()

    if old_str == "":
        full.parent.mkdir(parents=True, exist_ok=True)
        full.write_text(new_str, encoding="utf-8")
        return {"path": str(full), "action": "overwritten" if existed else "created"}

    if not existed:
        return {"path": str(full), "action": "error: file does not exist"}

    text = full.read_text(encoding="utf-8")
    if old_str not in text:
        return {"path": str(full), "action": "error: old_str not found"}

    full.write_text(text.replace(old_str, new_str, 1), encoding="utf-8")
    return {"path": str(full), "action": "edited"}


@tool
def terminal(command: str, cwd: str = ".") -> dict:
    """Run a shell command inside the project root and return stdout, stderr, returncode.
    Asks for human confirmation before running, since this executes arbitrary shell commands."""
    full_cwd = resolve_abs_path(cwd)

    confirm = input(f"\n[confirm] Run command: `{command}` in {full_cwd} ? [y/N] ").strip().lower()
    if confirm != "y":
        return {"command": command, "cwd": str(full_cwd), "error": "rejected by user"}

    try:
        r = subprocess.run(
            command, shell=True, cwd=str(full_cwd),
            capture_output=True, text=True, timeout=60,
        )
        return {
            "command": command, "cwd": str(full_cwd),
            "stdout": r.stdout, "stderr": r.stderr, "returncode": r.returncode,
        }
    except subprocess.TimeoutExpired:
        return {"command": command, "cwd": str(full_cwd), "error": "timeout after 60s"}


TOOLS = [read_file, list_files, edit_file, terminal]

# ---------- Graph state ----------

class AgentState(TypedDict):
    messages: Annotated[Sequence[BaseMessage], add_messages]


llm = ChatOllama(
        model=OLLAMA_MODEL,
        base_url=OLLAMA_BASE_URL,
        temperature=0,
        client_kwargs={
            "headers": {"Authorization": f"Bearer {OLLAMA_API_KEY}"}
        }
    )

def _truncate(text: str, limit: int = 500) -> str:
    text = str(text)
    return text if len(text) <= limit else text[:limit] + f"... [truncated, {len(text)} chars total]"


def model_node(state: AgentState) -> dict:
    resp = llm.invoke(state["messages"])

    if getattr(resp, "tool_calls", None):
        for call in resp.tool_calls:
            args_str = json.dumps(call["args"], ensure_ascii=False)
            print(f"\n[tool call] {call['name']}({args_str})")
    # else: final answer for this turn, printed by the run loop once the graph finishes

    return {"messages": [resp]}


def tools_verbose_node(state: AgentState) -> dict:
    """Wraps ToolNode's execution to print each tool's result as it runs."""
    result = ToolNode(TOOLS).invoke(state)
    for msg in result["messages"]:
        if isinstance(msg, ToolMessage):
            print(f"[tool result: {msg.name}] {_truncate(msg.content)}")
    return result


def should_continue(state: AgentState) -> str:
    last = state["messages"][-1]
    return "tools" if getattr(last, "tool_calls", None) else END


# ---------- Build the graph ----------

builder = StateGraph(AgentState)
builder.add_node("model", model_node)
builder.add_node("tools", tools_verbose_node)

builder.add_edge(START, "model")
builder.add_conditional_edges("model", should_continue, {"tools": "tools", END: END})
builder.add_edge("tools", "model")  # after running tools, go back to the model

agent = builder.compile(checkpointer=MemorySaver())

# ---------- Run loop ----------

if __name__ == "__main__":
    thread = {"configurable": {"thread_id": "1"}}
    system = SystemMessage(
        content=(
            "You are a coding assistant with tools: read_file(filename: str), list_files(path: str = '.'), edit_file(path: str, old_str: str, new_str: str) so you can Edit a file. If old_str is empty, create/overwrite the file with new_str."
            "Otherwise replace the first occurrence of old_str with new_str, "
            "and terminal(command: str, cwd: str = '.') which Run a shell command inside the project root and return stdout, stderr, returncode."
            "Asks for human confirmation before running, since this executes arbitrary shell commands."
            "You have no other tools at your hand other than these 4"
            "Use them to accomplish tasks. All paths are relative to the "
            f"project root: {PROJECT_ROOT}"
        )
    )

    # Seed the system message into the thread's persisted state once.
    agent.invoke({"messages": [system]}, config=thread)

    while True:
        try:
            user = input("You: ").strip()
        except (KeyboardInterrupt, EOFError):
            print()
            break

        if not user:
            continue
        if user.lower() in {"exit", "quit"}:
            break

        try:
            print("[thinking...]")
            # The checkpointer already holds prior history for this thread_id,
            # so we only need to send the new message each turn.
            res = agent.invoke({"messages": [HumanMessage(content=user)]}, config=thread)
            last = res["messages"][-1]
            if isinstance(last, AIMessage):
                print("\nAssistant:", last.content)
        except Exception as e:
            print(f"[error] {e}")
