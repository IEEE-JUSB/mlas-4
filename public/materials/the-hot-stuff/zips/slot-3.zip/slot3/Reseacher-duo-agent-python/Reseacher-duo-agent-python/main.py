from typing import TypedDict, Annotated

import os
from langchain_ollama import ChatOllama
from langgraph.graph import StateGraph, END
from dotenv import load_dotenv

load_dotenv()

OLLAMA_MODEL = os.getenv("OLLAMA_MODEL")
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL")
OLLAMA_API_KEY = os.getenv("OLLAMA_API_KEY")

class AgentState(TypedDict):
    """State carried through the research/writing workflow."""

    topic: str
    research_notes: str
    final_summary: str


# Connect to the local Ollama server using an installed Llama model.
# llm = ChatOllama(model="llama3.2:latest", base_url="http://localhost:11434")


llm = ChatOllama(
        model=OLLAMA_MODEL,
        base_url=OLLAMA_BASE_URL,
        temperature=0,
        client_kwargs={
            "headers": {"Authorization": f"Bearer {OLLAMA_API_KEY}"}
        }
    )

def researcher_node(state: AgentState) -> AgentState:
    """Research the user topic and collect a few factual notes."""
    topic = state["topic"]

    prompt = f"""
    You are a research assistant.
    Research the topic: {topic}

    Produce 3 or 4 concise, factual bullet points.
    Keep each bullet brief and easy to understand.
    Do not include extra commentary or a heading.
    """

    response = llm.invoke(prompt)
    state["research_notes"] = response.content.strip()
    return state


def writer_node(state: AgentState) -> AgentState:
    """Turn the notes into a brief executive summary in Markdown."""
    notes = state["research_notes"]

    prompt = f"""
    You are a technical writer.
    Create a brief executive summary in Markdown based only on these notes:

    {notes}

    Requirements:
    - Use Markdown headings and bullet points.
    - Keep it concise and professional.
    - Make the summary easy for a non-expert to read.
    """

    response = llm.invoke(prompt)
    state["final_summary"] = response.content.strip()
    return state


# Build the workflow: START -> researcher -> writer -> END
workflow = StateGraph(AgentState)
workflow.add_node("researcher", researcher_node)
workflow.add_node("writer", writer_node)
workflow.set_entry_point("researcher")
workflow.add_edge("researcher", "writer")
workflow.add_edge("writer", END)

app = workflow.compile()


if __name__ == "__main__":
    topic = "The advantages of solid-state EV batteries"

    print("\n=== Researcher Duo Demo ===")
    print(f"Topic: {topic}\n")

    result = app.invoke({"topic": topic, "research_notes": "", "final_summary": ""})

    print("\n--- Researcher Agent Output ---")
    print(result["research_notes"])

    print("\n--- Writer Agent Output ---")
    print(result["final_summary"])
