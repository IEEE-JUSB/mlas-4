paste it in .env
Write in terminal: uv venv
Write in terminal: .venv\Scripts\activate
Write in terminal: uv pip install -r requirements.txt
Click top bar -> write '>' -> write 'Reload window' -> reloads the window
Write in terminal: python agent.py