from langchain_core.prompts import PromptTemplate
from langchain_ollama import ChatOllama
from dotenv import load_dotenv
import os

load_dotenv()

OLLAMA_API_KEY = os.getenv("OLLAMA_API_KEY", "")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3.2:1b")
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434") 

def solve(problem_prompt: str, example_test: str) -> str:
    template = """Solve this problem in Python.

Problem:
{problem}

Test:
{example_test}"""

    prompt = PromptTemplate.from_template(template)
    
    llm = ChatOllama(
        model=OLLAMA_MODEL,
        base_url=OLLAMA_BASE_URL,
        temperature=1.0, 
        client_kwargs={
            "headers": {"Authorization": f"Bearer {OLLAMA_API_KEY}"}
        } if OLLAMA_API_KEY else {}
    )
    
    chain = prompt | llm
    
    response = chain.invoke({
        "problem": problem_prompt, 
        "example_test": example_test
    })
    
    raw_output = response.content

    return raw_output