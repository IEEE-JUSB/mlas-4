import json
import subprocess
import tempfile
import os
from agent import solve

def run_custom_eval():
    with open("problems.json", "r") as f:
        problems = json.load(f)
        
    passed_tasks = 0
    
    for p in problems:
        print(f"\n--- Running Task {p['task_id']} ---")
        
        # 1. Pass ONLY the first test to the LLM as the visible example
        generated_code = solve(p["prompt"], p["tests"][0])
        
        all_tests_passed = True
        
        # 2. Iterate through every test assert for this problem
        for i, test_assertion in enumerate(p["tests"]):
            
            # Append ONE test assertion to the generated function
            test_script = generated_code + "\n\n" + test_assertion
            
            with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as tmp:
                tmp.write(test_script)
                tmp_path = tmp.name
                
            try:
                # 3. Execute the temporary file
                result = subprocess.run(
                    ["python3", tmp_path],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                
                # Check if the assert crashed
                if result.returncode != 0:
                    # Isolate the exact error (e.g., AssertionError, SyntaxError)
                    error_lines = result.stderr.strip().split('\n')
                    error_msg = error_lines[-1] if error_lines else "Unknown Error"
                    print(f"  Test {i+1} FAIL: {error_msg}")
                    all_tests_passed = False
                else:
                    print(f"  Test {i+1} PASS")
                    
            except subprocess.TimeoutExpired:
                print(f"  Test {i+1} FAIL (Timeout)")
                all_tests_passed = False
            finally:
                os.remove(tmp_path)
                
        if all_tests_passed:
            print(f"Task {p['task_id']}: OVERALL PASS")
            passed_tasks += 1
        else:
            print(f"Task {p['task_id']}: OVERALL FAIL")
            
    print(f"\nLeaderboard Score: {passed_tasks}/{len(problems)}")

if __name__ == "__main__":
    run_custom_eval()