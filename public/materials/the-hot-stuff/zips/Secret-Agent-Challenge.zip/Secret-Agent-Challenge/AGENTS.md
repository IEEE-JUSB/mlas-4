# Secret Agent Challenge: Participant Guide

Your mission is to build an AI agent capable of writing Python solvers for logic puzzles. The provided baseline model is small, chaotic, and intentionally unoptimized. If you run it as-is, it will generate syntax errors, hallucinate function names, and fail test cases. 

Your goal is to use LangChain, LangGraph, and Python to nurse this model to a perfect score. Best of Luck!

## The Three Golden Rules

1. **Edit ONLY `agent.py`** 
   This is your entire workspace. Build your prompts, output parsers, tools, and agentic retry loops entirely within this file.
   
2. **The Entry Point Must Remain `solve()`** 
   The benchmarking system automatically imports and calls your agent. You may create as many helper functions or LangGraph nodes as you want, but the final exposed function at the bottom of the file **MUST** be:
   `def solve(problem_prompt: str, example_test: str) -> str:`

3. **DO NOT Touch Other Files** 
   Do not modify `runner.py` or `problems.json`. Your code will be evaluated against a hidden, unmodified test suite using the original runner architecture. Tampering with the runner will result in an automatic score of 0.

---

**To test your progress:**
Run `python runner.py` in your terminal to see your live score on the visible test cases.