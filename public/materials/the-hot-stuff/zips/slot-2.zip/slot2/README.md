Notebook 1: https://colab.research.google.com/drive/1TpzaUIt8mxZISwrjXm2RSHkvd-KPwObC
Notebook 2: https://colab.research.google.com/drive/1adLb1pt-yS6oo2yTQstCnURhN43TMNc2
Notebook 3: https://colab.research.google.com/drive/16YhiszfXdz6qxCaEs8BCwc_cqLi84I7T
Notebook 4: https://colab.research.google.com/drive/1fQSygfRZ7uygVaWHsE8xK9lmJQLPPbE2